﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2
{
    public class User
    {
        private string userName;
        private string name;
        private string email;
        private string password;
        private string address;
        private int[] phone = new int[3];
        private int[] card = new int[4];
        private double balance;

        public User()
        {
            this.userName = "Guest";
            this.name = "";
            this.email = "";
            this.password = "";
            this.address = "";
            this.balance = 0.0;
        }

        public string UserName
        {
            get
            {
                return this.userName;
            }
            set
            {
                this.userName = value;
            }
        }

        public string Name
        {
            get
            {
                return this.name;
            }
            set
            {
                this.name = value;
            }
        }

        public string Email
        {
            get
            {
                return this.email;
            }
            set
            {
                this.email = value;
            }
        }

        public string Password
        {
            get
            {
                return this.password;
            }
            set
            {
                this.password = value;
            }
        }

        public string Address
        {
            get
            {
                return this.address;
            }
            set
            {
                this.address = value;
            }
        }

        public int[] Phone
        {
            get
            {
                return this.phone;
            }
            set
            {
                for(int i = 0; i < 3; i++)
                {
                    this.phone[i] = value[i];
                }
            }
        }

        public int[] Card
        {
            get
            {
                return this.card;
            }
            set
            {
                for (int i = 0; i < 4; i++)
                {
                    this.card[i] = value[i];
                }
            }
        }

        public double Balance
        {
            get
            {
                return this.balance;
            }
            set
            {
                this.balance = value;
            }
        }
    }

}
