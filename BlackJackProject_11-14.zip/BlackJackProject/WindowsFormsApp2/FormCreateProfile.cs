﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class FormCreateProfile : Form
    {

        static Profile menuForm = new Profile();

        public Profile RefToMenu { get; set; }

        public User user { get; set; }


        public FormCreateProfile()
        {
            InitializeComponent();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            user.UserName = textBoxUser.Text;
            user.Name = textBoxName.Text;

            this.RefToMenu.LoadText();
            this.RefToMenu.Show();
            this.Close();
        }

        private void FormCreateProfile_Load(object sender, EventArgs e)
        {
            textBoxUser.Text = user.UserName;
            textBoxName.Text = user.FirstName + " " + user.LastName;
            textBoxEmail.Text = user.Email;
            textBoxPhone1.Text = user.Phone[0].ToString();
            textBoxPhone2.Text = user.Phone[1].ToString();
            textBoxPhone3.Text = user.Phone[2].ToString();
        }
    }
}
