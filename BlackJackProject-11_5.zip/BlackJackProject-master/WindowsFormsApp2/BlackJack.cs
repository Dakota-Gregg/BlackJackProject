﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form

    {

        CardStore deck = new CardStore();
        Hand player = new Hand();
        Hand dealer = new Hand();

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonBet_Click(object sender, EventArgs e)
        {
            double balance, bet;
            balance = Convert.ToDouble(lblBalance.Text);
            bet = Convert.ToDouble(textBet.Text);

            balance = balance - bet;
            lblCurrentPot.Text = string.Format("{0:C}", bet);
            lblBalance.Text = string.Format("{0:C}", balance);

        }

        private void buttonNewHand_Click(object sender, EventArgs e)
        {
            player.setScore(0);
            while (player.getAces() > 0)
            {
                player.decreaseAces();
            }

            dealer.setScore(0);
            while (dealer.getAces() > 0)
            {
                dealer.decreaseAces();
            }

            deck.reset();
            NewHand();
        }

        private void buttonStay_Click(object sender, EventArgs e)
        {
            while (dealer.getScore() < 17)
            {
                dealer.DrawCard(deck);

                if (dealer.getScore() > 21 && dealer.getAces() >= 1)
                {
                    dealer.setScore(dealer.getScore() - 10);
                    dealer.decreaseAces();
                }
            }

            labelDealerScore.Text = dealer.getScore().ToString();

            CalculateWinner();
        }

        private void buttonHit_Click(object sender, EventArgs e)
        {
            if(player.getScore() >= 21)
            {
                CalculateWinner();
                return;
            }

            player.DrawCard(deck);

            if (dealer.getScore() < 17)
            {
                dealer.DrawCard(deck);

                if (dealer.getScore() > 21 && dealer.getAces() >= 1)
                {
                    dealer.setScore(dealer.getScore() - 10);
                    dealer.decreaseAces();
                }
            }

            if (player.getScore() > 21 && player.getAces() >= 1)
            {
                player.setScore(player.getScore() - 10);
                player.decreaseAces();
            }

            labelPlayerScore.Text = player.getScore().ToString();
            labelDealerScore.Text = dealer.getScore().ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            NewHand();
        }

        private void NewHand()
        {
            labelDealerScore.Visible = false;

            for (int x = 0; x < 2; x++)
            {
                player.DrawCard(deck);
                //List<Card> cardList = player.GetCardList();
                //Card card = cardList.First();
                //boxP1.Image = Image.FromFile(card.GetImage());
                dealer.DrawCard(deck);
            }

            labelPlayerScore.Text = player.getScore().ToString();
            labelDealerScore.Text = dealer.getScore().ToString();
        }

        private void CalculateWinner()
        {
            if(player.getScore() == 21)
            {
                Console.WriteLine("Player Wins!");
            }
            else if(player.getScore() > 21)
            {
                Console.WriteLine("Dealers Wins!");
            }
            else if(dealer.getScore() == 21)
            {
                Console.WriteLine("Dealers Wins!");
            }
            else if (dealer.getScore() > 21)
            {
                Console.WriteLine("Player Wins!");
            }
            else
            {
                if(player.getScore() > dealer.getScore())
                {
                    Console.WriteLine("Player Wins!");
                }
                else if (player.getScore() == dealer.getScore())
                {
                    dealer.DrawCard(deck);
                    CalculateWinner();
                }
                else
                {
                    Console.WriteLine("Dealer Wins!");
                }
            }

            labelDealerScore.Visible = true;
        }
    }
}
