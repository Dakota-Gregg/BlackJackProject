﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Collections.Specialized;
using System.Net.Mail;

namespace WindowsFormsApp2
{
    public partial class FormLogin : Form
    {

        public User user { get; set; }

        string username;
        string password;

        public FormLogin()
        {
            InitializeComponent();
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            username = textBoxUser.Text;
            password = textBoxPassword.Text;

            LoadUser();
        }

        private void LoadUser()
        {
            ExeConfigurationFileMap configMap = new ExeConfigurationFileMap();
            string filePath = @"..\..\Users\" + username + ".config";
            try
            {
                configMap.ExeConfigFilename = filePath;
                Configuration config = ConfigurationManager.OpenMappedExeConfiguration(configMap, ConfigurationUserLevel.None);

                if ( (username == config.AppSettings.Settings["Username"].Value && password == config.AppSettings.Settings["Password"].Value))
                {
                    user.UserName = config.AppSettings.Settings["Username"].Value;
                    user.Password = config.AppSettings.Settings["Password"].Value;
                    user.Name = config.AppSettings.Settings["Name"].Value;
                    user.Email = new MailAddress(config.AppSettings.Settings["Email"].Value);
                    user.Address = config.AppSettings.Settings["Address"].Value;
                    user.Balance = Int32.Parse(config.AppSettings.Settings["Balance"].Value);
                    user.Win = Int32.Parse(config.AppSettings.Settings["Win"].Value);
                    user.Lose = Int32.Parse(config.AppSettings.Settings["Lose"].Value);

                    FormPlayGame form = new FormPlayGame();
                    form.LoadText();
                    this.Close();
                }
                else
                {
                    labelError.Text = "Incorrect Password";
                    labelError.Visible = true;
                }
            }
            catch
            {
                labelError.Text = "User Does Not Exist";
                labelError.Visible = true;
            }
        }
    }
}
