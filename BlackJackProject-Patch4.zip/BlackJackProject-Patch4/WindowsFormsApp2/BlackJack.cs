﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form

    {
        int count=0;
        int dcount = 0;
        CardStore deck = new CardStore();
        Hand player = new Hand();
        Hand dealer = new Hand();
        int payout = 2;
        double blackjackpayout = 2.5;
        double balance = 20;
        double pot = 0;
        double bet = 0;
        
        public Form RefToMenu { get; set; }

        public Form1()
        {
            InitializeComponent();
           
        }

        private void buttonBet_Click(object sender, EventArgs e)
        {
            if (textBoxBet.Text == "")
                Console.WriteLine("Error: No Bet Entered");
            else
            {
                try
                {
                    bet = Convert.ToDouble(textBoxBet.Text);
                    if (bet > balance)
                        Console.WriteLine("Error: Not enough balance for bet");
                    else
                    {
                        pot = pot + bet;
                        balance = balance - bet;
                        formatPot(pot);
                        formatBalance(balance);
                        textBoxBet.Text = "";
                    }
                }
                catch
                {
                    Console.WriteLine("Error: Please input a valid bet amount");
                }
            }
        }

        private void formatPot(double amount)
        {
            lblCurrentPot.Text = string.Format("{0:C}", amount);
        }

        private void formatBalance(double amount)
        {
            lblBalance.Text = string.Format("{0:C}", amount);
        }

        private void dealerWin()
        {
            pot = 0;
            formatPot(pot);
            lblDealerWins.Visible = true;
        }

        private void playerWin()
        {
            balance = balance + (pot * payout);
            pot = 0;
            formatBalance(balance);
            formatPot(pot);
            lblPlayerWins.Visible = true;
        }

        private void playerBlackJack()
        {
            balance = balance + (pot * blackjackpayout);
            pot = 0;
            formatBalance(balance);
            formatPot(pot);
            lblDealerWins.Visible = true;
        }

        private void buttonNewHand_Click(object sender, EventArgs e)
        {
            lblDealerWins.Visible = false;
            lblPlayerWins.Visible = false;
            player.setScore(0);
            while (player.getAces() > 0)
            {
                player.decreaseAces();
            }

            dealer.setScore(0);
            while (dealer.getAces() > 0)
            {
                dealer.decreaseAces();
            }

            deck.reset();
            player.reset();
            dealer.reset();
            NewHand();
        }

        private void buttonStay_Click(object sender, EventArgs e)
        {
            buttonHit.Enabled = false;
            while (dealer.getScore() < 17)
            {
                dealer.DrawCard(deck);
                if (dealer.getScore() > 21)
                {
                    if (dealer.getAces() >= 1)
                    {
                        dealer.setScore(dealer.getScore() - 10);
                        dealer.decreaseAces();
                    }
                }
            }

            labelDealerScore.Text = dealer.getScore().ToString();

            CalculateWinner();
        }

        private void buttonHit_Click(object sender, EventArgs e)
        {

            if (player.getScore() >= 21)
            {
                CalculateWinner();
                return;
            }


            player.DrawCard(deck);

            PictureBox[] Dboxes = { boxD1, boxD2, boxD3, boxD4, boxD5, boxD6, boxD7, boxD8 };
            PictureBox[] Pboxes = { boxP1, boxP2, boxP3, boxP4, boxP5, boxP6, boxP7, boxP8 };
            Pboxes[count].Visible = true;
            Pboxes[count].BringToFront();
            Pboxes[count].ImageLocation = player.GetCardList()[count];
            Pboxes[count].Refresh();

            if (dealer.getScore() < 17)
            {
                dealer.DrawCard(deck);
                Dboxes[count].ImageLocation = @"../../card-BMPs/b2fv.bmp";
                Dboxes[count].Visible = true;
                Dboxes[count].BringToFront();
                dcount++;

                if (dealer.getScore() > 21 && dealer.getAces() >= 1)
                {
                    dealer.setScore(dealer.getScore() - 10);
                    dealer.decreaseAces();
                }
            }
            count++;
            if (player.getScore() > 21)
            { 
                if (player.getAces() >= 1)
                {
                    player.setScore(player.getScore() - 10);
                    player.decreaseAces();
                }
            }
            labelPlayerScore.Text = player.getScore().ToString();
            labelDealerScore.Text = dealer.getScore().ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            NewHand();
            formatPot(pot);
            formatBalance(balance);

        }

        private void NewHand()
        { 
            labelDealerScore.Visible = false;
            buttonNewHand.Enabled = false;
            buttonHit.Enabled = true;
            PictureBox[] Pboxes = { boxP1, boxP2, boxP3, boxP4, boxP5, boxP6, boxP7, boxP8 };
            PictureBox[] Dboxes = { boxD1, boxD2, boxD3, boxD4, boxD5, boxD6, boxD7, boxD8 };
            for (count = 0; count < 8; count++)
            {
                Pboxes[count].ImageLocation = null;
                Pboxes[count].Refresh();
                Pboxes[count].Visible = false;
            }
            for (count = 0; count < 8; count++)
            {
                Dboxes[count].ImageLocation = null;
                Dboxes[count].Refresh();
                Dboxes[count].Visible = false;
            }
            for ( count = 0; count < 2; count++)
            {
                player.DrawCard(deck);
                Pboxes[count].Visible = true;
                Pboxes[count].ImageLocation=player.GetCardList()[count];
                Pboxes[count].Refresh();

                //List<Card> cardList = player.GetCardList();
                //Card card = cardList.First();
                //boxP1.Image = Image.FromFile(card.GetImage());
                dealer.DrawCard(deck);
                Dboxes[count].Visible = true;
            }
            Dboxes[0].ImageLocation = dealer.GetCardList()[0];
            Dboxes[1].ImageLocation = @"../../card-BMPs/b2fv.bmp";
            dcount = 2;
            labelPlayerScore.Text = player.getScore().ToString();
            labelDealerScore.Text = dealer.getScore().ToString();
        }

        private void CalculateWinner()
        {
            buttonNewHand.Enabled = true;
            PictureBox[] Dboxes = { boxD1, boxD2, boxD3, boxD4, boxD5, boxD6, boxD7, boxD8 };
            for (int x=0;x<dcount;x++)
            {
                Dboxes[x].ImageLocation = dealer.GetCardList()[x];
                Dboxes[x].Refresh();
                Dboxes[x].BringToFront();
            }
            if (player.getScore() == 21)
            {
                Console.WriteLine("Player Wins!");
                if (count == 2)
                    playerBlackJack();
                else
                    playerWin();
            }
            else if(player.getScore() > 21)
            {
                Console.WriteLine("Dealers Wins!");
                dealerWin();
            }
            else if(dealer.getScore() == 21)
            {
                Console.WriteLine("Dealers Wins!");
                dealerWin();
            }
            else if (dealer.getScore() > 21)
            {
                Console.WriteLine("Player Wins!");
                playerWin();
            }
            else
            {
                if(player.getScore() > dealer.getScore())
                {
                    Console.WriteLine("Player Wins!");
                    playerWin();
                }
                else if (player.getScore() == dealer.getScore())
                {
                    dealer.DrawCard(deck);
                    CalculateWinner();
                }
                else
                {
                    Console.WriteLine("Dealer Wins!");
                    dealerWin();
                }
            }

            labelDealerScore.Visible = true;
        }

        private void boxP2_Click(object sender, EventArgs e)
        {

        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            

            System.IO.File.WriteAllText(@"../../Test.txt",lblBalance.Text);
            this.RefToMenu.Show();
            this.Close();
        }

        private void buttonLoad_Click(object sender, EventArgs e)
        {
            lblBalance.Text=System.IO.File.ReadAllText(@"../../Test.txt");
        }
    }
}
