﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Net.Mail;

namespace WindowsFormsApp2
{
    public partial class FormEditProfile : Form
    {
        private string EmptyError = "* Required Information *";
        private string NameError = "* Invalid Name *";
        private string LetterError = "* Name Requires at Least 5 Letters *";
        private string NumberError = "* Name Not Allowed Numbers *";
        private string EmailError = "* Email Not Valid *";
        private string PhoneError = "* Phone Number Not Valid *";
        private string CardError = "* Credit/Debit Card Not Valid *";
        private string ExpireError = "* This Card has Expired *";
        private string AddressError = "* Address Not Valid *";
        private string WithdrawError = "* Invalid ammount *";

        Regex invalid = new Regex(@"[^a-zA-Z0-9\.\@\!\$\#]");
        Regex letters = new Regex(@"[a-zA-Z]{5,}");
        Regex name = new Regex(@"[a-zA-z]");
        Regex numbers = new Regex(@"\d");
        Regex phone = new Regex(@"\b\d{10}\b");
        Regex card = new Regex(@"\b\d{16}\b");
        Regex ccv = new Regex(@"\b\d{3}\b");
        Regex ZIP = new Regex(@"\b\d{5}\b");
        Regex address = new Regex(@"(Dr|Ave|St|Rd|Blvd|Ln|Pkwy|Cir)", RegexOptions.IgnoreCase);
        Regex comma = new Regex(@",");

        static Profile menuForm = new Profile();

        public Profile RefToMenu { get; set; }

        public User user { get; set; }


        public FormEditProfile()
        {
            InitializeComponent();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            if (CheckValues())
            {
                this.RefToMenu.LoadText();
                this.RefToMenu.Show();
                this.Close();
            }
        }

        private void FormEditProfile_Load(object sender, EventArgs e)
        {
            textBoxPhone.TextMaskFormat = MaskFormat.ExcludePromptAndLiterals;
            textBoxCard.TextMaskFormat = MaskFormat.ExcludePromptAndLiterals;
            dateTimePicker.Format = DateTimePickerFormat.Custom;
            dateTimePicker.CustomFormat = ("MM/yy");

            textBoxUser.Text = user.UserName;
            textBoxName.Text = user.Name;
            textBoxEmail.Text = user.Email.ToString();
            textBoxPhone.Text = user.Phone.ToString();
            textBoxCard.Text = user.Card.CardNumber.ToString();
            textBoxCCV.Text = user.Card.CCVNumber.ToString();
            dateTimePicker.Value = user.Card.Expiration;

            string[] address = comma.Split(user.Address);
            try
            {
                textBoxAddress.Text = address[0];
            }
            catch
            {
                textBoxAddress.Text = "";

            }
            try
            {
                comboBoxStates.SelectedIndex = comboBoxStates.FindString(address[1].Trim());
            }
            catch
            {
                comboBoxStates.Text = "";

            }
            try
            {
                textBoxZIP.Text = Int32.Parse(address[2]).ToString();
            }
            catch
            {
                textBoxZIP.Text = "";

            }
            
        }

        private bool CheckValues()
        {
            bool test = false;
            bool userTest = false;
            bool nameTest = false;
            bool emailTest = false;
            bool phoneTest = false;
            bool addressTest = false;
            bool cardTest = false;

            if(textBoxUser.Text.Length == 0)
            {
                labelUserError.Text = EmptyError;
                labelUserError.Visible = true;
                userTest = false;
            }
            else if (invalid.IsMatch(textBoxUser.Text))
            {
                labelUserError.Text = NameError;
                labelUserError.Visible = true;
                userTest = false;
            }
            else if (!letters.IsMatch(textBoxUser.Text))
            {
                labelUserError.Text = LetterError;
                labelUserError.Visible = true;
                userTest = false;
            }
            else
            {
                user.UserName = textBoxUser.Text;
                labelUserError.Visible = false;
                userTest = true;

            }

            if (textBoxName.Text.Length == 0)
            {
                labelNameError.Text = EmptyError;
                labelNameError.Visible = true;
                nameTest = false;
            }
            else if (!name.IsMatch(textBoxName.Text))
            {
                labelNameError.Text = NameError;
                labelNameError.Visible = true;
                nameTest = false;
            }
            else if (numbers.IsMatch(textBoxName.Text))
            {
                labelNameError.Text = NumberError;
                labelNameError.Visible = true;
                nameTest = false;
            }
            else
            {
                user.Name = textBoxName.Text;
                labelNameError.Visible = false;
                nameTest = true;

            }

            if (textBoxEmail.Text.Length == 0)
            {
                labelEmailError.Text = EmptyError;
                labelEmailError.Visible = true;
                emailTest = false;
            }
            else if (invalid.IsMatch(textBoxEmail.Text))
            {
                labelEmailError.Text = NameError;
                labelEmailError.Visible = true;
                emailTest = false;
            }
            else
            {
                try
                {
                    MailAddress m = new MailAddress(textBoxEmail.Text);

                    user.Email = m;
                    labelEmailError.Visible = false;
                    emailTest = true;
                }
                catch (FormatException)
                {
                    labelEmailError.Text = EmailError;
                    labelEmailError.Visible = true;
                    emailTest = false;
                }
            }

            if (textBoxPhone.TextLength == 0 || !phone.IsMatch(textBoxPhone.Text))
            {
                labelPhoneError.Text = PhoneError;
                labelPhoneError.Visible = true;
                phoneTest = false;
            }
            else
            {
                int phone = Int32.Parse(textBoxPhone.Text);
                user.Phone = phone;
                labelPhoneError.Visible = false;
                phoneTest = true;
            }

            if (textBoxAddress.Text.Length == 0)
            {
                labelAddressError.Text = EmptyError;
                labelAddressError.Visible = true;
                addressTest = false;
            }
            else if (!(name.IsMatch(textBoxAddress.Text) && numbers.IsMatch(textBoxAddress.Text) && address.IsMatch(textBoxAddress.Text)))
            {
                labelAddressError.Text = AddressError;
                labelAddressError.Visible = true;
                addressTest = false;
            }
            else
            {
                labelAddressError.Visible = false;
                if (comboBoxStates.Text.Length == 0)
                {
                    labelStateError.Text = EmptyError;
                    labelStateError.Visible = true;
                    addressTest = false;
                }
                else
                {
                    if (!(ZIP.IsMatch(textBoxZIP.Text)))
                    {
                        labelStateError.Text = EmptyError;
                        labelStateError.Visible = true;
                        addressTest = false;
                    }
                    else
                    {
                        user.Address = String.Concat(textBoxAddress.Text, ", ", comboBoxStates.Text, ", ", textBoxZIP.Text);
                        labelStateError.Visible = false;
                        addressTest = true;
                    }
                }    
            }

            if (textBoxCard.TextLength == 0 || !card.IsMatch(textBoxCard.Text))
            {
                labelCardError.Text = CardError;
                labelCardError.Visible = true;
                cardTest = false;
            }
            else if (textBoxCCV.TextLength == 0 || !ccv.IsMatch(textBoxCCV.Text))
            {
                labelCardError.Text = CardError;
                labelCardError.Visible = true;
                cardTest = false;
            }
            else if (dateTimePicker.Value.Month <= DateTime.Now.Month && dateTimePicker.Value.Year <= DateTime.Now.Year)
            {
                labelCardError.Text = ExpireError;
                labelCardError.Visible = true;
                cardTest = false;
            }
            else
            {
                try
                {
                    CreditCard card = new CreditCard(long.Parse(textBoxCard.Text), Int32.Parse(textBoxCCV.Text), dateTimePicker.Value);

                    user.Card = card;
                    labelCardError.Visible = false;
                    cardTest = true;
                }
                catch
                {
                    labelCardError.Text = CardError;
                    labelCardError.Visible = true;
                    cardTest = false;
                }
            }
            if (userTest && nameTest && emailTest && phoneTest && addressTest && cardTest)
            {
                test = true;
            }
            return test;
        }

        private void buttonWithdraw_Click(object sender, EventArgs e)
        {
            if (textBoxMoney.Text.Length == 0)
            {
                labelWithdrawError.Text = EmptyError;
                labelWithdrawError.Visible = true;
            }
            else
            {
                try
                {
                    user.Balance += Double.Parse(textBoxMoney.Text);
                    MessageBox.Show("Charged $" + textBoxMoney.Text + " to card ending with " + user.Card.CardNumber.ToString().Insert(12, "-").Split('-')[1]);
                }
                catch
                {
                    labelWithdrawError.Text = WithdrawError;
                    labelWithdrawError.Visible = true;
                }
                
            }
            
        }

        private void buttonPasswordChange_Click(object sender, EventArgs e)
        {
            FormPasswordChange form = new FormPasswordChange();
            form.user = this.user;
            form.ShowDialog();
        }
    }
}
