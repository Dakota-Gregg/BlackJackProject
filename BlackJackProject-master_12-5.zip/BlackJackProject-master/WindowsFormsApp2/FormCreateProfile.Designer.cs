﻿namespace WindowsFormsApp2
{
    partial class FormCreateProfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelUser = new System.Windows.Forms.Label();
            this.labelName = new System.Windows.Forms.Label();
            this.labelEmail = new System.Windows.Forms.Label();
            this.labelPhone = new System.Windows.Forms.Label();
            this.labelAddress = new System.Windows.Forms.Label();
            this.labelCard = new System.Windows.Forms.Label();
            this.textBoxUser = new System.Windows.Forms.TextBox();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.textBoxEmail = new System.Windows.Forms.TextBox();
            this.textBoxAddress = new System.Windows.Forms.TextBox();
            this.labelState = new System.Windows.Forms.Label();
            this.labelZip = new System.Windows.Forms.Label();
            this.buttonSave = new System.Windows.Forms.Button();
            this.labelUserError = new System.Windows.Forms.Label();
            this.labelNameError = new System.Windows.Forms.Label();
            this.labelEmailError = new System.Windows.Forms.Label();
            this.labelPhoneError = new System.Windows.Forms.Label();
            this.labelAddressError = new System.Windows.Forms.Label();
            this.labelStateError = new System.Windows.Forms.Label();
            this.labelCardError = new System.Windows.Forms.Label();
            this.comboBoxStates = new System.Windows.Forms.ComboBox();
            this.labelPassword = new System.Windows.Forms.Label();
            this.labelPasswordConfirm = new System.Windows.Forms.Label();
            this.textBoxPasswordConfirm = new System.Windows.Forms.TextBox();
            this.textBoxPassword = new System.Windows.Forms.TextBox();
            this.labelPasswordError = new System.Windows.Forms.Label();
            this.textBoxPhone = new System.Windows.Forms.MaskedTextBox();
            this.textBoxCard = new System.Windows.Forms.MaskedTextBox();
            this.textBoxZIP = new System.Windows.Forms.MaskedTextBox();
            this.labelCCV = new System.Windows.Forms.Label();
            this.textBoxCCV = new System.Windows.Forms.MaskedTextBox();
            this.labelExpire = new System.Windows.Forms.Label();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.comboBoxSecurityQuestion = new System.Windows.Forms.ComboBox();
            this.labelSecurityQuestion = new System.Windows.Forms.Label();
            this.labelSecurityAnswer = new System.Windows.Forms.Label();
            this.textBoxSecurityAnswer = new System.Windows.Forms.TextBox();
            this.labelQuestionError = new System.Windows.Forms.Label();
            this.groupBoxBasic = new System.Windows.Forms.GroupBox();
            this.groupBoxSecurity = new System.Windows.Forms.GroupBox();
            this.groupBoxPayment = new System.Windows.Forms.GroupBox();
            this.groupBoxBasic.SuspendLayout();
            this.groupBoxSecurity.SuspendLayout();
            this.groupBoxPayment.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelUser
            // 
            this.labelUser.AutoSize = true;
            this.labelUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUser.Location = new System.Drawing.Point(22, 33);
            this.labelUser.Name = "labelUser";
            this.labelUser.Size = new System.Drawing.Size(129, 26);
            this.labelUser.TabIndex = 1;
            this.labelUser.Text = "User Name:";
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName.Location = new System.Drawing.Point(22, 73);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(77, 26);
            this.labelName.TabIndex = 2;
            this.labelName.Text = "Name:";
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEmail.Location = new System.Drawing.Point(22, 115);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(74, 26);
            this.labelEmail.TabIndex = 3;
            this.labelEmail.Text = "Email:";
            // 
            // labelPhone
            // 
            this.labelPhone.AutoSize = true;
            this.labelPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPhone.Location = new System.Drawing.Point(22, 156);
            this.labelPhone.Name = "labelPhone";
            this.labelPhone.Size = new System.Drawing.Size(81, 26);
            this.labelPhone.TabIndex = 4;
            this.labelPhone.Text = "Phone:";
            // 
            // labelAddress
            // 
            this.labelAddress.AutoSize = true;
            this.labelAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAddress.Location = new System.Drawing.Point(22, 199);
            this.labelAddress.Name = "labelAddress";
            this.labelAddress.Size = new System.Drawing.Size(98, 26);
            this.labelAddress.TabIndex = 5;
            this.labelAddress.Text = "Address:";
            // 
            // labelCard
            // 
            this.labelCard.AutoSize = true;
            this.labelCard.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCard.Location = new System.Drawing.Point(8, 31);
            this.labelCard.Name = "labelCard";
            this.labelCard.Size = new System.Drawing.Size(186, 26);
            this.labelCard.TabIndex = 6;
            this.labelCard.Text = "Credit/Debit Card:";
            // 
            // textBoxUser
            // 
            this.textBoxUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxUser.Location = new System.Drawing.Point(157, 34);
            this.textBoxUser.Name = "textBoxUser";
            this.textBoxUser.Size = new System.Drawing.Size(132, 26);
            this.textBoxUser.TabIndex = 1;
            // 
            // textBoxName
            // 
            this.textBoxName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxName.Location = new System.Drawing.Point(105, 73);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(184, 26);
            this.textBoxName.TabIndex = 2;
            // 
            // textBoxEmail
            // 
            this.textBoxEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxEmail.Location = new System.Drawing.Point(105, 115);
            this.textBoxEmail.Name = "textBoxEmail";
            this.textBoxEmail.Size = new System.Drawing.Size(184, 26);
            this.textBoxEmail.TabIndex = 3;
            // 
            // textBoxAddress
            // 
            this.textBoxAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxAddress.Location = new System.Drawing.Point(126, 199);
            this.textBoxAddress.Name = "textBoxAddress";
            this.textBoxAddress.Size = new System.Drawing.Size(163, 26);
            this.textBoxAddress.TabIndex = 5;
            // 
            // labelState
            // 
            this.labelState.AutoSize = true;
            this.labelState.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelState.Location = new System.Drawing.Point(22, 240);
            this.labelState.Name = "labelState";
            this.labelState.Size = new System.Drawing.Size(69, 26);
            this.labelState.TabIndex = 14;
            this.labelState.Text = "State:";
            // 
            // labelZip
            // 
            this.labelZip.AutoSize = true;
            this.labelZip.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelZip.Location = new System.Drawing.Point(157, 245);
            this.labelZip.Name = "labelZip";
            this.labelZip.Size = new System.Drawing.Size(106, 26);
            this.labelZip.TabIndex = 15;
            this.labelZip.Text = "Zip Code:";
            // 
            // buttonSave
            // 
            this.buttonSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.buttonSave.Location = new System.Drawing.Point(249, 610);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(144, 33);
            this.buttonSave.TabIndex = 15;
            this.buttonSave.Text = "Save Profile";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // labelUserError
            // 
            this.labelUserError.AutoSize = true;
            this.labelUserError.ForeColor = System.Drawing.Color.Red;
            this.labelUserError.Location = new System.Drawing.Point(295, 42);
            this.labelUserError.Name = "labelUserError";
            this.labelUserError.Size = new System.Drawing.Size(37, 13);
            this.labelUserError.TabIndex = 23;
            this.labelUserError.Text = "*Error*";
            this.labelUserError.Visible = false;
            // 
            // labelNameError
            // 
            this.labelNameError.AutoSize = true;
            this.labelNameError.ForeColor = System.Drawing.Color.Red;
            this.labelNameError.Location = new System.Drawing.Point(295, 81);
            this.labelNameError.Name = "labelNameError";
            this.labelNameError.Size = new System.Drawing.Size(37, 13);
            this.labelNameError.TabIndex = 24;
            this.labelNameError.Text = "*Error*";
            this.labelNameError.Visible = false;
            // 
            // labelEmailError
            // 
            this.labelEmailError.AutoSize = true;
            this.labelEmailError.ForeColor = System.Drawing.Color.Red;
            this.labelEmailError.Location = new System.Drawing.Point(295, 123);
            this.labelEmailError.Name = "labelEmailError";
            this.labelEmailError.Size = new System.Drawing.Size(37, 13);
            this.labelEmailError.TabIndex = 25;
            this.labelEmailError.Text = "*Error*";
            this.labelEmailError.Visible = false;
            // 
            // labelPhoneError
            // 
            this.labelPhoneError.AutoSize = true;
            this.labelPhoneError.ForeColor = System.Drawing.Color.Red;
            this.labelPhoneError.Location = new System.Drawing.Point(236, 164);
            this.labelPhoneError.Name = "labelPhoneError";
            this.labelPhoneError.Size = new System.Drawing.Size(37, 13);
            this.labelPhoneError.TabIndex = 26;
            this.labelPhoneError.Text = "*Error*";
            this.labelPhoneError.Visible = false;
            // 
            // labelAddressError
            // 
            this.labelAddressError.AutoSize = true;
            this.labelAddressError.ForeColor = System.Drawing.Color.Red;
            this.labelAddressError.Location = new System.Drawing.Point(295, 207);
            this.labelAddressError.Name = "labelAddressError";
            this.labelAddressError.Size = new System.Drawing.Size(37, 13);
            this.labelAddressError.TabIndex = 27;
            this.labelAddressError.Text = "*Error*";
            this.labelAddressError.Visible = false;
            // 
            // labelStateError
            // 
            this.labelStateError.AutoSize = true;
            this.labelStateError.ForeColor = System.Drawing.Color.Red;
            this.labelStateError.Location = new System.Drawing.Point(328, 249);
            this.labelStateError.Name = "labelStateError";
            this.labelStateError.Size = new System.Drawing.Size(37, 13);
            this.labelStateError.TabIndex = 28;
            this.labelStateError.Text = "*Error*";
            this.labelStateError.Visible = false;
            // 
            // labelCardError
            // 
            this.labelCardError.AutoSize = true;
            this.labelCardError.ForeColor = System.Drawing.Color.Red;
            this.labelCardError.Location = new System.Drawing.Point(378, 39);
            this.labelCardError.Name = "labelCardError";
            this.labelCardError.Size = new System.Drawing.Size(37, 13);
            this.labelCardError.TabIndex = 29;
            this.labelCardError.Text = "*Error*";
            this.labelCardError.Visible = false;
            // 
            // comboBoxStates
            // 
            this.comboBoxStates.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxStates.FormattingEnabled = true;
            this.comboBoxStates.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.comboBoxStates.Items.AddRange(new object[] {
            "AL",
            "AK",
            "AZ",
            "AR",
            "CA",
            "CO",
            "CT",
            "DC",
            "DE",
            "FL",
            "GA",
            "HI",
            "ID",
            "IL",
            "IN",
            "IA",
            "KS",
            "KY",
            "LA",
            "ME",
            "MD",
            "MA",
            "MI",
            "MN",
            "MS",
            "MO",
            "MT",
            "NE",
            "NV",
            "NH",
            "NJ",
            "NM",
            "NY",
            "NC",
            "ND",
            "OH",
            "OK",
            "OR",
            "PA",
            "RI",
            "SC",
            "SD",
            "TN",
            "TX",
            "UT",
            "VT",
            "VA",
            "WA",
            "WV",
            "WI",
            "WY",
            "Other"});
            this.comboBoxStates.Location = new System.Drawing.Point(97, 245);
            this.comboBoxStates.Name = "comboBoxStates";
            this.comboBoxStates.Size = new System.Drawing.Size(54, 21);
            this.comboBoxStates.TabIndex = 6;
            // 
            // labelPassword
            // 
            this.labelPassword.AutoSize = true;
            this.labelPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPassword.Location = new System.Drawing.Point(82, 27);
            this.labelPassword.Name = "labelPassword";
            this.labelPassword.Size = new System.Drawing.Size(114, 26);
            this.labelPassword.TabIndex = 30;
            this.labelPassword.Text = "Password:";
            // 
            // labelPasswordConfirm
            // 
            this.labelPasswordConfirm.AutoSize = true;
            this.labelPasswordConfirm.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPasswordConfirm.Location = new System.Drawing.Point(6, 66);
            this.labelPasswordConfirm.Name = "labelPasswordConfirm";
            this.labelPasswordConfirm.Size = new System.Drawing.Size(197, 26);
            this.labelPasswordConfirm.TabIndex = 31;
            this.labelPasswordConfirm.Text = "Confirm Password:";
            // 
            // textBoxPasswordConfirm
            // 
            this.textBoxPasswordConfirm.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxPasswordConfirm.Location = new System.Drawing.Point(209, 66);
            this.textBoxPasswordConfirm.Name = "textBoxPasswordConfirm";
            this.textBoxPasswordConfirm.PasswordChar = '*';
            this.textBoxPasswordConfirm.Size = new System.Drawing.Size(184, 26);
            this.textBoxPasswordConfirm.TabIndex = 12;
            // 
            // textBoxPassword
            // 
            this.textBoxPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxPassword.Location = new System.Drawing.Point(209, 27);
            this.textBoxPassword.Name = "textBoxPassword";
            this.textBoxPassword.PasswordChar = '*';
            this.textBoxPassword.Size = new System.Drawing.Size(184, 26);
            this.textBoxPassword.TabIndex = 11;
            // 
            // labelPasswordError
            // 
            this.labelPasswordError.AutoSize = true;
            this.labelPasswordError.ForeColor = System.Drawing.Color.Red;
            this.labelPasswordError.Location = new System.Drawing.Point(399, 74);
            this.labelPasswordError.Name = "labelPasswordError";
            this.labelPasswordError.Size = new System.Drawing.Size(37, 13);
            this.labelPasswordError.TabIndex = 34;
            this.labelPasswordError.Text = "*Error*";
            this.labelPasswordError.Visible = false;
            // 
            // textBoxPhone
            // 
            this.textBoxPhone.AllowPromptAsInput = false;
            this.textBoxPhone.BeepOnError = true;
            this.textBoxPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.textBoxPhone.Location = new System.Drawing.Point(105, 156);
            this.textBoxPhone.Mask = "(999) 000-0000";
            this.textBoxPhone.Name = "textBoxPhone";
            this.textBoxPhone.Size = new System.Drawing.Size(125, 26);
            this.textBoxPhone.TabIndex = 4;
            // 
            // textBoxCard
            // 
            this.textBoxCard.AllowPromptAsInput = false;
            this.textBoxCard.BeepOnError = true;
            this.textBoxCard.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.textBoxCard.Location = new System.Drawing.Point(200, 31);
            this.textBoxCard.Mask = "0000-0000-0000-0000";
            this.textBoxCard.Name = "textBoxCard";
            this.textBoxCard.Size = new System.Drawing.Size(172, 26);
            this.textBoxCard.TabIndex = 8;
            // 
            // textBoxZIP
            // 
            this.textBoxZIP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.textBoxZIP.Location = new System.Drawing.Point(269, 245);
            this.textBoxZIP.Mask = "00000";
            this.textBoxZIP.Name = "textBoxZIP";
            this.textBoxZIP.Size = new System.Drawing.Size(53, 26);
            this.textBoxZIP.TabIndex = 7;
            this.textBoxZIP.ValidatingType = typeof(int);
            // 
            // labelCCV
            // 
            this.labelCCV.AutoSize = true;
            this.labelCCV.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCCV.Location = new System.Drawing.Point(8, 69);
            this.labelCCV.Name = "labelCCV";
            this.labelCCV.Size = new System.Drawing.Size(65, 26);
            this.labelCCV.TabIndex = 37;
            this.labelCCV.Text = "CCV:";
            // 
            // textBoxCCV
            // 
            this.textBoxCCV.BeepOnError = true;
            this.textBoxCCV.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.textBoxCCV.Location = new System.Drawing.Point(79, 69);
            this.textBoxCCV.Mask = "000";
            this.textBoxCCV.Name = "textBoxCCV";
            this.textBoxCCV.Size = new System.Drawing.Size(43, 26);
            this.textBoxCCV.TabIndex = 9;
            this.textBoxCCV.ValidatingType = typeof(int);
            // 
            // labelExpire
            // 
            this.labelExpire.AutoSize = true;
            this.labelExpire.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelExpire.Location = new System.Drawing.Point(139, 69);
            this.labelExpire.Name = "labelExpire";
            this.labelExpire.Size = new System.Drawing.Size(167, 26);
            this.labelExpire.TabIndex = 39;
            this.labelExpire.Text = "Expiration Date:";
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.CustomFormat = "MM/yy";
            this.dateTimePicker.Location = new System.Drawing.Point(313, 72);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(59, 20);
            this.dateTimePicker.TabIndex = 10;
            this.dateTimePicker.Value = new System.DateTime(2019, 11, 25, 0, 0, 0, 0);
            // 
            // comboBoxSecurityQuestion
            // 
            this.comboBoxSecurityQuestion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSecurityQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.comboBoxSecurityQuestion.FormattingEnabled = true;
            this.comboBoxSecurityQuestion.Items.AddRange(new object[] {
            "What is the city where you were born?",
            "What is your mothers maiden name?",
            "What is your first Pets name?",
            "Who is your high school sweetheart?",
            "What is the name of your favorite childhood friend?",
            "What is your first cars make and model?",
            "What was your childhood nickname?",
            "What is your oldest siblings middle name?",
            "What is the name of your first stuffed animal?",
            "What is your oldest cousins first and last name?"});
            this.comboBoxSecurityQuestion.Location = new System.Drawing.Point(200, 106);
            this.comboBoxSecurityQuestion.Name = "comboBoxSecurityQuestion";
            this.comboBoxSecurityQuestion.Size = new System.Drawing.Size(365, 28);
            this.comboBoxSecurityQuestion.TabIndex = 13;
            // 
            // labelSecurityQuestion
            // 
            this.labelSecurityQuestion.AutoSize = true;
            this.labelSecurityQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSecurityQuestion.Location = new System.Drawing.Point(6, 106);
            this.labelSecurityQuestion.Name = "labelSecurityQuestion";
            this.labelSecurityQuestion.Size = new System.Drawing.Size(190, 26);
            this.labelSecurityQuestion.TabIndex = 42;
            this.labelSecurityQuestion.Text = "Security Question:";
            // 
            // labelSecurityAnswer
            // 
            this.labelSecurityAnswer.AutoSize = true;
            this.labelSecurityAnswer.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSecurityAnswer.Location = new System.Drawing.Point(105, 142);
            this.labelSecurityAnswer.Name = "labelSecurityAnswer";
            this.labelSecurityAnswer.Size = new System.Drawing.Size(91, 26);
            this.labelSecurityAnswer.TabIndex = 43;
            this.labelSecurityAnswer.Text = "Answer:";
            // 
            // textBoxSecurityAnswer
            // 
            this.textBoxSecurityAnswer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSecurityAnswer.Location = new System.Drawing.Point(209, 142);
            this.textBoxSecurityAnswer.Name = "textBoxSecurityAnswer";
            this.textBoxSecurityAnswer.Size = new System.Drawing.Size(184, 26);
            this.textBoxSecurityAnswer.TabIndex = 14;
            // 
            // labelQuestionError
            // 
            this.labelQuestionError.AutoSize = true;
            this.labelQuestionError.ForeColor = System.Drawing.Color.Red;
            this.labelQuestionError.Location = new System.Drawing.Point(399, 147);
            this.labelQuestionError.Name = "labelQuestionError";
            this.labelQuestionError.Size = new System.Drawing.Size(37, 13);
            this.labelQuestionError.TabIndex = 45;
            this.labelQuestionError.Text = "*Error*";
            this.labelQuestionError.Visible = false;
            // 
            // groupBoxBasic
            // 
            this.groupBoxBasic.Controls.Add(this.labelUser);
            this.groupBoxBasic.Controls.Add(this.labelName);
            this.groupBoxBasic.Controls.Add(this.labelEmail);
            this.groupBoxBasic.Controls.Add(this.labelPhone);
            this.groupBoxBasic.Controls.Add(this.textBoxUser);
            this.groupBoxBasic.Controls.Add(this.textBoxName);
            this.groupBoxBasic.Controls.Add(this.textBoxEmail);
            this.groupBoxBasic.Controls.Add(this.textBoxPhone);
            this.groupBoxBasic.Controls.Add(this.labelAddress);
            this.groupBoxBasic.Controls.Add(this.textBoxAddress);
            this.groupBoxBasic.Controls.Add(this.textBoxZIP);
            this.groupBoxBasic.Controls.Add(this.labelState);
            this.groupBoxBasic.Controls.Add(this.comboBoxStates);
            this.groupBoxBasic.Controls.Add(this.labelZip);
            this.groupBoxBasic.Controls.Add(this.labelStateError);
            this.groupBoxBasic.Controls.Add(this.labelAddressError);
            this.groupBoxBasic.Controls.Add(this.labelPhoneError);
            this.groupBoxBasic.Controls.Add(this.labelNameError);
            this.groupBoxBasic.Controls.Add(this.labelEmailError);
            this.groupBoxBasic.Controls.Add(this.labelUserError);
            this.groupBoxBasic.Location = new System.Drawing.Point(87, 12);
            this.groupBoxBasic.Name = "groupBoxBasic";
            this.groupBoxBasic.Size = new System.Drawing.Size(571, 282);
            this.groupBoxBasic.TabIndex = 16;
            this.groupBoxBasic.TabStop = false;
            this.groupBoxBasic.Text = "Basic Information";
            // 
            // groupBoxSecurity
            // 
            this.groupBoxSecurity.Controls.Add(this.labelSecurityAnswer);
            this.groupBoxSecurity.Controls.Add(this.labelSecurityQuestion);
            this.groupBoxSecurity.Controls.Add(this.labelQuestionError);
            this.groupBoxSecurity.Controls.Add(this.labelPasswordConfirm);
            this.groupBoxSecurity.Controls.Add(this.textBoxSecurityAnswer);
            this.groupBoxSecurity.Controls.Add(this.labelPassword);
            this.groupBoxSecurity.Controls.Add(this.comboBoxSecurityQuestion);
            this.groupBoxSecurity.Controls.Add(this.labelPasswordError);
            this.groupBoxSecurity.Controls.Add(this.textBoxPassword);
            this.groupBoxSecurity.Controls.Add(this.textBoxPasswordConfirm);
            this.groupBoxSecurity.Location = new System.Drawing.Point(87, 423);
            this.groupBoxSecurity.Name = "groupBoxSecurity";
            this.groupBoxSecurity.Size = new System.Drawing.Size(571, 177);
            this.groupBoxSecurity.TabIndex = 18;
            this.groupBoxSecurity.TabStop = false;
            this.groupBoxSecurity.Text = "Security Information";
            // 
            // groupBoxPayment
            // 
            this.groupBoxPayment.Controls.Add(this.textBoxCCV);
            this.groupBoxPayment.Controls.Add(this.labelCCV);
            this.groupBoxPayment.Controls.Add(this.labelCard);
            this.groupBoxPayment.Controls.Add(this.dateTimePicker);
            this.groupBoxPayment.Controls.Add(this.textBoxCard);
            this.groupBoxPayment.Controls.Add(this.labelExpire);
            this.groupBoxPayment.Controls.Add(this.labelCardError);
            this.groupBoxPayment.Location = new System.Drawing.Point(87, 300);
            this.groupBoxPayment.Name = "groupBoxPayment";
            this.groupBoxPayment.Size = new System.Drawing.Size(571, 117);
            this.groupBoxPayment.TabIndex = 17;
            this.groupBoxPayment.TabStop = false;
            this.groupBoxPayment.Text = "Payment Information";
            // 
            // FormCreateProfile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 655);
            this.ControlBox = false;
            this.Controls.Add(this.groupBoxPayment);
            this.Controls.Add(this.groupBoxSecurity);
            this.Controls.Add(this.groupBoxBasic);
            this.Controls.Add(this.buttonSave);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormCreateProfile";
            this.Text = "FormCreateProfile";
            this.Load += new System.EventHandler(this.FormCreateProfile_Load);
            this.groupBoxBasic.ResumeLayout(false);
            this.groupBoxBasic.PerformLayout();
            this.groupBoxSecurity.ResumeLayout(false);
            this.groupBoxSecurity.PerformLayout();
            this.groupBoxPayment.ResumeLayout(false);
            this.groupBoxPayment.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label labelUser;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.Label labelPhone;
        private System.Windows.Forms.Label labelAddress;
        private System.Windows.Forms.Label labelCard;
        private System.Windows.Forms.TextBox textBoxUser;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.TextBox textBoxEmail;
        private System.Windows.Forms.TextBox textBoxAddress;
        private System.Windows.Forms.Label labelState;
        private System.Windows.Forms.Label labelZip;
        private System.Windows.Forms.Button buttonSave;
        private System.Windows.Forms.Label labelUserError;
        private System.Windows.Forms.Label labelNameError;
        private System.Windows.Forms.Label labelEmailError;
        private System.Windows.Forms.Label labelPhoneError;
        private System.Windows.Forms.Label labelAddressError;
        private System.Windows.Forms.Label labelStateError;
        private System.Windows.Forms.Label labelCardError;
        private System.Windows.Forms.ComboBox comboBoxStates;
        private System.Windows.Forms.Label labelPassword;
        private System.Windows.Forms.Label labelPasswordConfirm;
        private System.Windows.Forms.TextBox textBoxPasswordConfirm;
        private System.Windows.Forms.TextBox textBoxPassword;
        private System.Windows.Forms.Label labelPasswordError;
        private System.Windows.Forms.MaskedTextBox textBoxPhone;
        private System.Windows.Forms.MaskedTextBox textBoxCard;
        private System.Windows.Forms.MaskedTextBox textBoxZIP;
        private System.Windows.Forms.Label labelCCV;
        private System.Windows.Forms.MaskedTextBox textBoxCCV;
        private System.Windows.Forms.Label labelExpire;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
        private System.Windows.Forms.ComboBox comboBoxSecurityQuestion;
        private System.Windows.Forms.Label labelSecurityQuestion;
        private System.Windows.Forms.Label labelSecurityAnswer;
        private System.Windows.Forms.TextBox textBoxSecurityAnswer;
        private System.Windows.Forms.Label labelQuestionError;
        private System.Windows.Forms.GroupBox groupBoxBasic;
        private System.Windows.Forms.GroupBox groupBoxSecurity;
        private System.Windows.Forms.GroupBox groupBoxPayment;
    }
}