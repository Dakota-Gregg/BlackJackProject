﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2
{
    public class CreditCard
    {
        private long cardNumber;
        private int CCV;
        private DateTime expiration;

        public CreditCard(long cardNumber, int CCV, DateTime expiration)
        {
            this.cardNumber = cardNumber;
            this.CCV = CCV;
            this.expiration = expiration;
        }

        public long CardNumber
        {
            get
            {
                return this.cardNumber;
            }
            set
            {
                this.cardNumber = value;
            }
        }
        public int CCVNumber
        {
            get
            {
                return this.CCV;
            }
            set
            {
                this.CCV = value;
            }
        }
        public DateTime Expiration
        {
            get
            {
                return this.expiration;
            }
            set
            {
                this.expiration = value;
            }
        }

    }
}
