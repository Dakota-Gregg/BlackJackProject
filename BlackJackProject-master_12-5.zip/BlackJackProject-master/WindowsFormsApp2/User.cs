﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Mail;

namespace WindowsFormsApp2
{
    public class User
    {
        private string userName;
        private string name;
        private MailAddress email;
        private string password;
        private string address;
        private int phone;
        private CreditCard card;
        private double balance;
        private int win;
        private int lose;

        private string question;
        private string answer;

        private Hand player = new Hand();
        private Hand dealer = new Hand();

        public User()
        {
            this.userName = "Guest";
            this.name = "";
            this.email = new MailAddress("Guest@test.com");
            this.card = new CreditCard(0, 0, DateTime.Now);
            this.password = "";
            this.address = "";
            this.balance = 20.0;
            this.win = 0;
            this.lose = 0;
           

            
        }

        public string UserName
        {
            get
            {
                return this.userName;
            }
            set
            {
                this.userName = value;
            }
        }

        public string Name
        {
            get
            {
                return this.name;
            }
            set
            {
                this.name = value;
            }
        }

        public MailAddress Email
        {
            get
            {
                return this.email;
            }
            set
            {
                this.email = value;
            }
        }

        public string Password
        {
            get
            {
                return this.password;
            }
            set
            {
                this.password = value;
            }
        }

        public string Question
        {
            get
            {
                return this.question;
            }
            set
            {
                this.question = value;
            }
        }

        public string Answer
        {
            get
            {
                return this.answer;
            }
            set
            {
                this.answer = value;
            }
        }

        public string Address
        {
            get
            {
                return this.address;
            }
            set
            {
                this.address = value;
            }
        }

        public int Phone
        {
            get
            {
                return this.phone;
            }
            set
            {
                this.phone = value;
            }
        }

        public CreditCard Card
        {
            get
            {
                return this.card;
            }
            set
            {
                this.card = value;
            }
        }

        public double Balance
        {
            get
            {
                return this.balance;
            }
            set
            {
                this.balance = value;
            }
        }

        public int Win
        {
            get
            {
                return this.win;
            }
            set
            {
                this.win = value;
            }
        }

        public int Lose
        {
            get
            {
                return this.lose;
            }
            set
            {
                this.lose = value;
            }
        }

        public Hand Player
        {
            get
            {
                return this.player;
            }
            set
            {
                this.player = value;
            }
        }

        public Hand Dealer
        {
            get
            {
                return this.dealer;
            }
            set
            {
                this.dealer = value;
            }
        }
    }

}
