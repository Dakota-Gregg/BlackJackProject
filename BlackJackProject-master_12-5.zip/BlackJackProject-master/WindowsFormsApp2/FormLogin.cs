﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Collections.Specialized;
using System.Net.Mail;
using System.Text.RegularExpressions;

namespace WindowsFormsApp2
{
    public partial class FormLogin : Form
    {
        private string UserError = "* Incorrect User or Password *";
        private string UserLoginError = "* User Already Logged In *";

        public User user { get; set; }

        public FormPlayGame RefToMenu { get; set; }


        string username;
        string password;

        public FormLogin()
        {
            InitializeComponent();
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            username = textBoxUser.Text;
            password = textBoxPassword.Text;

            FindUser();
            RefToMenu.LoadText();
        }

        private void FindUser()
        {
            ExeConfigurationFileMap configMap = new ExeConfigurationFileMap();
            string filePath = @"..\..\Users\" + username + ".config";
            try
            {
                System.IO.File.Decrypt(filePath);
                configMap.ExeConfigFilename = filePath;
                Configuration config = ConfigurationManager.OpenMappedExeConfiguration(configMap, ConfigurationUserLevel.None);
                if (username == user.UserName)
                {
                    labelError.Text = UserLoginError;
                    labelError.Visible = true;
                    System.IO.File.Encrypt(filePath);
                }
                else if ( (username == config.AppSettings.Settings["Username"].Value && (RefToMenu.Hash(password) == config.AppSettings.Settings["Password"].Value || (password == user.Password && username == user.UserName))))
                {
                    LoadUser(config);
                    System.IO.File.Encrypt(filePath);
                }
                else
                {
                    labelError.Text = UserError;
                    labelError.Visible = true;
                    System.IO.File.Encrypt(filePath);

                }
            }
            catch
            {
                labelError.Text = UserError;
                labelError.Visible = true;
                System.IO.File.Encrypt(filePath);

            }
        }

        private void LoadUser(Configuration config)
        {
            if (user.Password.Length == 0)
            {
                user.Password = password;
            } else
            {
                if(!(user.UserName == "Guest" && user.Email.ToString() == "Guest@test.com"))
                {
                    user.Password = password;
                }
            }
            user.UserName = config.AppSettings.Settings["Username"].Value;
            user.Name = config.AppSettings.Settings["Name"].Value;
            user.Email = new MailAddress(config.AppSettings.Settings["Email"].Value);
            user.Address = config.AppSettings.Settings["Address"].Value;
            user.Balance = Int32.Parse(config.AppSettings.Settings["Balance"].Value);
            user.Win = Int32.Parse(config.AppSettings.Settings["Win"].Value);
            user.Lose = Int32.Parse(config.AppSettings.Settings["Lose"].Value);
            user.Player.Score = Int32.Parse(config.AppSettings.Settings["PlayerScore"].Value);
            user.Player.Aces = Int32.Parse(config.AppSettings.Settings["PlayerAce"].Value);
            user.Dealer.Score = Int32.Parse(config.AppSettings.Settings["DealerScore"].Value);
            user.Dealer.Score = Int32.Parse(config.AppSettings.Settings["DealerScore"].Value);
            user.Question = config.AppSettings.Settings["Question"].Value;
            user.Answer = config.AppSettings.Settings["Answer"].Value;

            user.Phone = Int32.Parse(config.AppSettings.Settings["Phone"].Value);
            user.Card = new CreditCard(long.Parse(config.AppSettings.Settings["Card"].Value), Int32.Parse(config.AppSettings.Settings["CCV"].Value), DateTime.Parse(config.AppSettings.Settings["Expiration"].Value));

            int cardCount = Int32.Parse(config.AppSettings.Settings["PlayerCardCount"].Value);
         
            for (int x = 0; x < cardCount; x++)
            {
                user.Player.CardList.Add(config.AppSettings.Settings["PlayerCard" + x].Value);
            }

            cardCount = Int32.Parse(config.AppSettings.Settings["DealerCardCount"].Value);
            for (int x = 0; x < cardCount; x++)
            {
                user.Dealer.CardList.Add(config.AppSettings.Settings["DealerCard" + x].Value);
            }
      


            RefToMenu.LoadText();
            this.Close();
        }

        private void linkLabelPassword_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            username = textBoxUser.Text;

            ExeConfigurationFileMap configMap = new ExeConfigurationFileMap();
            string filePath = @"..\..\Users\" + username + ".config";
            try
            {
                configMap.ExeConfigFilename = filePath;
                Configuration config = ConfigurationManager.OpenMappedExeConfiguration(configMap, ConfigurationUserLevel.None);

                if (username == config.AppSettings.Settings["Username"].Value)
                {
                    user.Question = config.AppSettings.Settings["Question"].Value;
                    user.Answer = config.AppSettings.Settings["Answer"].Value;
                    user.Password = config.AppSettings.Settings["Password"].Value;
                    user.UserName = config.AppSettings.Settings["Username"].Value;

                    FormPasswordChange form = new FormPasswordChange();
                    form.RefToMenu = this.RefToMenu;
                    form.user = this.user;
                    form.ShowDialog();

                }
                else
                {
                    labelError.Text = UserError;
                    labelError.Visible = true;
                }
            }
            catch
            {
                labelError.Text = UserError;
                labelError.Visible = true;
            }
        }
    }
}