﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Collections.Specialized;
using System.Net.Mail;
using System.Text.RegularExpressions;

namespace WindowsFormsApp2
{
    public partial class FormPasswordChange : Form
    {

        public User user { get; set; }
        public FormPlayGame RefToMenu { get; set; }


        public FormPasswordChange()
        {
            InitializeComponent();
        }

        private void TextChangedEvent(object Sender, EventArgs e)
        {
            CheckAnswer();
        }
        private void buttonLogin_Click(object sender, EventArgs e)
        {
            string EmptyError = "* Required Information *";
            string PasswordError = "* Invalid Password *";
            string PasswordMatchError = "* Passwords Do Not Match *";
            Regex invalid = new Regex(@"[^a-zA-Z0-9\.\@\!\$\#]");

            bool passwordTest = false;

            if (textBoxPassword1.Text.Length == 0)
            {
                labelError.Text = EmptyError;
                labelError.Visible = true;
                passwordTest = false;
            }
            else if (invalid.IsMatch(textBoxPassword1.Text))
            {
                labelError.Text = PasswordError;
                labelError.Visible = true;
                passwordTest = false;
            }
            else if (RefToMenu.Hash(textBoxPassword1.Text) == user.Password)
            {
                labelError.Text = PasswordError;
                labelError.Visible = true;
                passwordTest = false;
            }
            else if (!(textBoxPassword1.Text == textBoxPassword2.Text))
            {
                labelError.Text = PasswordMatchError;
                labelError.Visible = true;
                passwordTest = false;
            }
            else
            {
                user.Password = textBoxPassword1.Text;
                labelError.Visible = false;
                passwordTest = true;
            }

            if (passwordTest)
            {
                this.Close();
            }

        }

        private void FormPasswordChange_Load(object sender, EventArgs e)
        {
            labelSecurityQuestion.Text = user.Question;
            labelPassword.Visible = false;
            labelPassConfirm.Visible = false;
            textBoxPassword1.Visible = false;
            textBoxPassword2.Visible = false;

            textBoxAnswer.TextChanged += new EventHandler(TextChangedEvent);

        }

        private void CheckAnswer()
        {


            if (String.Compare(user.Answer, textBoxAnswer.Text) == 0)
            {
                textBoxAnswer.Enabled = false;
                labelPassword.Visible = true;
                labelPassConfirm.Visible = true;
                textBoxPassword1.Visible = true;
                textBoxPassword2.Visible = true;
            }

        }
    }
}