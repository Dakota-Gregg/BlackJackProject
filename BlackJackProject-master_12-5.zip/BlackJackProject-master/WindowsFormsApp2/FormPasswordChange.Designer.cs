﻿namespace WindowsFormsApp2
{
    partial class FormPasswordChange
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelSecurityQuestion = new System.Windows.Forms.Label();
            this.labelAnswer = new System.Windows.Forms.Label();
            this.textBoxAnswer = new System.Windows.Forms.TextBox();
            this.buttonUpdate = new System.Windows.Forms.Button();
            this.labelError = new System.Windows.Forms.Label();
            this.textBoxPassword1 = new System.Windows.Forms.TextBox();
            this.labelPassword = new System.Windows.Forms.Label();
            this.textBoxPassword2 = new System.Windows.Forms.TextBox();
            this.labelPassConfirm = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // labelSecurityQuestion
            // 
            this.labelSecurityQuestion.AutoSize = true;
            this.labelSecurityQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.labelSecurityQuestion.Location = new System.Drawing.Point(78, 48);
            this.labelSecurityQuestion.Name = "labelSecurityQuestion";
            this.labelSecurityQuestion.Size = new System.Drawing.Size(158, 24);
            this.labelSecurityQuestion.TabIndex = 0;
            this.labelSecurityQuestion.Text = "Security Question";
            // 
            // labelAnswer
            // 
            this.labelAnswer.AutoSize = true;
            this.labelAnswer.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.labelAnswer.Location = new System.Drawing.Point(28, 96);
            this.labelAnswer.Name = "labelAnswer";
            this.labelAnswer.Size = new System.Drawing.Size(79, 24);
            this.labelAnswer.TabIndex = 1;
            this.labelAnswer.Text = "Answer:";
            // 
            // textBoxAnswer
            // 
            this.textBoxAnswer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.textBoxAnswer.Location = new System.Drawing.Point(113, 96);
            this.textBoxAnswer.Name = "textBoxAnswer";
            this.textBoxAnswer.PasswordChar = '*';
            this.textBoxAnswer.Size = new System.Drawing.Size(170, 26);
            this.textBoxAnswer.TabIndex = 1;
            // 
            // buttonUpdate
            // 
            this.buttonUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.buttonUpdate.Location = new System.Drawing.Point(147, 204);
            this.buttonUpdate.Name = "buttonUpdate";
            this.buttonUpdate.Size = new System.Drawing.Size(103, 40);
            this.buttonUpdate.TabIndex = 4;
            this.buttonUpdate.Text = "Update";
            this.buttonUpdate.UseVisualStyleBackColor = true;
            this.buttonUpdate.Click += new System.EventHandler(this.buttonLogin_Click);
            // 
            // labelError
            // 
            this.labelError.AutoSize = true;
            this.labelError.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.labelError.ForeColor = System.Drawing.Color.Red;
            this.labelError.Location = new System.Drawing.Point(118, 9);
            this.labelError.Name = "labelError";
            this.labelError.Size = new System.Drawing.Size(49, 17);
            this.labelError.TabIndex = 5;
            this.labelError.Text = "*error*";
            this.labelError.Visible = false;
            // 
            // textBoxPassword1
            // 
            this.textBoxPassword1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.textBoxPassword1.Location = new System.Drawing.Point(175, 140);
            this.textBoxPassword1.Name = "textBoxPassword1";
            this.textBoxPassword1.PasswordChar = '*';
            this.textBoxPassword1.Size = new System.Drawing.Size(170, 26);
            this.textBoxPassword1.TabIndex = 2;
            // 
            // labelPassword
            // 
            this.labelPassword.AutoSize = true;
            this.labelPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.labelPassword.Location = new System.Drawing.Point(28, 139);
            this.labelPassword.Name = "labelPassword";
            this.labelPassword.Size = new System.Drawing.Size(141, 24);
            this.labelPassword.TabIndex = 6;
            this.labelPassword.Text = "New Password:";
            // 
            // textBoxPassword2
            // 
            this.textBoxPassword2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.textBoxPassword2.Location = new System.Drawing.Point(175, 172);
            this.textBoxPassword2.Name = "textBoxPassword2";
            this.textBoxPassword2.PasswordChar = '*';
            this.textBoxPassword2.Size = new System.Drawing.Size(170, 26);
            this.textBoxPassword2.TabIndex = 3;
            // 
            // labelPassConfirm
            // 
            this.labelPassConfirm.AutoSize = true;
            this.labelPassConfirm.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.labelPassConfirm.Location = new System.Drawing.Point(2, 172);
            this.labelPassConfirm.Name = "labelPassConfirm";
            this.labelPassConfirm.Size = new System.Drawing.Size(167, 24);
            this.labelPassConfirm.TabIndex = 8;
            this.labelPassConfirm.Text = "Confirm Password:";
            // 
            // FormPasswordChange
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(449, 256);
            this.Controls.Add(this.textBoxPassword2);
            this.Controls.Add(this.labelPassConfirm);
            this.Controls.Add(this.textBoxPassword1);
            this.Controls.Add(this.labelPassword);
            this.Controls.Add(this.labelError);
            this.Controls.Add(this.buttonUpdate);
            this.Controls.Add(this.textBoxAnswer);
            this.Controls.Add(this.labelAnswer);
            this.Controls.Add(this.labelSecurityQuestion);
            this.Name = "FormPasswordChange";
            this.Text = "FormLogin";
            this.Load += new System.EventHandler(this.FormPasswordChange_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelSecurityQuestion;
        private System.Windows.Forms.Label labelAnswer;
        private System.Windows.Forms.TextBox textBoxAnswer;
        private System.Windows.Forms.Button buttonUpdate;
        private System.Windows.Forms.Label labelError;
        private System.Windows.Forms.TextBox textBoxPassword1;
        private System.Windows.Forms.Label labelPassword;
        private System.Windows.Forms.TextBox textBoxPassword2;
        private System.Windows.Forms.Label labelPassConfirm;
    }
}