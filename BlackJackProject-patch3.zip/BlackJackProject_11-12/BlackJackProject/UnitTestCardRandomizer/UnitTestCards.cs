﻿
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestCards
{
    [TestClass]
    public class UnitTestCardRandomizer
    {
        [TestMethod]
        public void Test()
        {
        }
    }
}
